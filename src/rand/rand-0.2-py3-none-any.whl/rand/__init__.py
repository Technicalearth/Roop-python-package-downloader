import random

def intrand():
    a = input("Enter the first number: ")
    b = input("Enter the last number: ")
    a = int(a)
    b = int(b)
    int_random_no = random.randint(a, b)
    print(int_random_no)

def floatrand():
    c = input("Enter the first number: ")
    d = input("Enter the last number: ")
    c = int(c)
    d = int(d)
    float_random_no = random.randint(c, d)
    float_random_no = float(float_random_no)
    print(float_random_no)