import random

def intrand():
    a = input("Enter the first number: ")
    b = input("Enter the last number: ")
    a = int(a)
    b = int(b)
    int_random_no = random.randint(a, b)
    print(int_random_no)

def floatrand():
    c = input("Enter the first number: ")
    d = input("Enter the last number: ")
    c = int(c)
    d = int(d)
    float_random_no = random.randint(c, d)
    float_random_no = float(float_random_no)
    print(float_random_no)

def even():
    e = input("Enter a number: ")
    e =  int(e)
    num = 0
    while num<=e:
        print(num)
        num = num + 2

def odd():
    f = input("Enter a number: ")
    f = int(f)
    number = 1
    while number<=f:
        print(number)
        number = number + 2