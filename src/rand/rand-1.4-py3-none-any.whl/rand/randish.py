import random
import rand

def rand_add():
    a = input("Enter a number: ")
    b = input("Enter another number: ")
    a = int(a)
    b = int(b)
    print("the added no. of", a,"and", b, "is :" ,a+b)
    c = a+b
    randno = random.randint(0, c)
    print(randno)