import random

def rand():
    a = input("Enter the first number: ")
    b = input("Enter the last number: ")
    a = int(a)
    b = int(b)
    random_no = random.randint(a, b)
    print(random_no)