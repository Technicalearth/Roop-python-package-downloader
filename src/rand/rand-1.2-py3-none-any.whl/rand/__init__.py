from time import sleep
import random

def intrand():
    a = input("Enter the first number: ")
    b = input("Enter the last number: ")
    a = int(a)
    b = int(b)
    int_random_no = random.randint(a, b)
    print(int_random_no)

def floatrand():
    c = input("Enter the first number: ")
    d = input("Enter the last number: ")
    c = int(c)
    d = int(d)
    float_random_no = random.randint(c, d)
    float_random_no = float(float_random_no)
    print(float_random_no)

def even():
    e = input("Enter a number: ")
    e =  int(e)
    num = 0
    while num<=e:
        print(num)
        num = num + 2

def odd():
    f = input("Enter a number: ")
    f = int(f)
    number = 1
    while number<=f:
        print(number)
        number = number + 2

def add():
    g = input("Enter a number: ")
    h = input("Enter another number: ")
    g = int(g)
    h = int(h)
    print("Adding numbers\n")
    sleep(2)
    print("Please wait\n")
    sleep(3)
    print(g+h)

def substract():
    i = input("Enter a number: ")
    j = input("Enter another number: ")
    i = int(i)
    j = int(j)
    print("Substracting numbers\n")
    sleep(2)
    print("Please wait\n")
    sleep(3)
    print(i-j)

def multiply():
    k = input("Enter a number: ")
    l = input("Enter another number: ")
    k = int(k)
    l = int(l)
    print("Multiplying numbers\n")
    sleep(2)
    print("Please wait\n")
    sleep(3)
    print(k*l)

def divide():
    m = input("Enter a number: ")
    n = input("Enter another number: ")
    m = int(m)
    n = int(n)
    print("Dividing numbers\n")
    sleep(2)
    print("Please wait\n")
    sleep(3)
    print(m/n)

def rand_add():
    o = input("Enter a number: ")
    p = input("Enter another number: ")
    o = int(o)
    p = int(p)
    print("The added no. of", o," and", p, "is :" ,o+p)
    q = o+p
    randno = random.randint(0, q)
    print("The random number is :" ,randno)

def rand_multiply():
    r = input("Enter a number: ")
    s = input("Enter another number: ")
    r = int(r)
    s = int(s)
    print("The multiplied number of", r, "and", s, "is :" ,r*s)
    t = r*s
    u = random.randint(0, t)
    print("The random number is :" ,u)

def rand_substract():
    v = input("Enter a number: ")
    w = input("Enter another number: ")
    v = int(v)
    w = int(w)
    print("The substracted number of", v, "and", w, "is :" ,v-w)
    x = v-w
    y = random.randint(0, x)
    print("The random number is:" ,y)

def rand_divide():
    z = input("Enter a number: ")
    aa = input("Enter another number: ")
    z = int(z)
    aa = int(aa)
    print("The divided number of", z, "and", aa, "is :" ,z/aa)
    ab = z/aa
    ac = random.randint(0, ab)
    print("The random number is:" ,ac)

def multi_add():
    ad = input("Enter a number: ")
    ae = input("Enter another number: ")
    af = input("Enter another number: ")
    ad = int(ad)
    ae = int(ae)
    af = int(af)
    print("The added no. of", ad,",", ae ,"and", af, "is :" ,ad+ae+af)
    ag = ad+ae+af
    ai = random.randint(0, ag)
    print("The random number is :" ,ai)

def multi_multiply():
    aj = input("Enter a number: ")
    ak = input("Enter another number: ")
    al = input("Enter another number: ")
    aj = int(aj)
    ak = int(ak)
    al = int(al)
    print("The multiplied no. of", aj,",", ak ,"and", al, "is :" ,aj*ak*al)
    am = aj+ak+al
    an = random.randint(0, am)
    print("The random number is :" ,an)

def multi_divide():
    ao = input("Enter a number: ")
    ap = input("Enter another number: ")
    aq = input("Enter another number: ")
    ao = int(ao)
    ap = int(ap)
    aq = int(aq)
    print("The divided no. of", ao,",", ap ,"and", aq, "is :" ,ao/ap/aq)
    ar = ao+ap+aq
    at = random.randint(0, ar)
    print("The random number is :" ,at)

def multi_substract():
    at = input("Enter a number: ")
    au = input("Enter another number: ")
    av = input("Enter another number: ")
    at = int(at)
    au = int(au)
    av = int(av)
    print("The substracted no. of", at,",", au ,"and", av, "is :" ,at-au-av)
    aw = at-au-av
    ax = random.randint(0, aw)
    print("The random number is :" ,ax)

def two_rand():
    ay = input("Enter a number: ")
    ay = int(ay)
    az = input("Enter another number: ")
    az = int(az)
    ba = random.randint(ay, az)
    print(ba)
    print(ba)

def three_rand():
    bb = input("Enter a number: ")
    bb = int(bb)
    bc = input("Enter another number: ")
    bc = int(bc)
    bd = random.randint(bb, bc)
    print(bd)
    print(bd)
    print(bd)

def ten_rand():
    bb = input("Enter a number: ")
    bb = int(bb)
    bc = input("Enter another number: ")
    bc = int(bc)
    bd = random.randint(bb, bc)
    print(bd)
    print(bd)
    print(bd)
    print(bd)
    print(bd)
    print(bd)
    print(bd)
    print(bd)
    print(bd)
    print(bd)

def twenty_rand():
    bb = input("Enter a number: ")
    bb = int(bb)
    bc = input("Enter another number: ")
    bc = int(bc)
    bd = random.randint(bb, bc)
    print(bd)
    print(bd)
    print(bd)
    print(bd)
    print(bd)
    print(bd)
    print(bd)
    print(bd)
    print(bd)
    print(bd)
    print(bd)
    print(bd)
    print(bd)
    print(bd)
    print(bd)
    print(bd)
    print(bd)
    print(bd)
    print(bd)
    print(bd)